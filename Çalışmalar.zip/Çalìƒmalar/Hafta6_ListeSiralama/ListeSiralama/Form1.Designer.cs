﻿
namespace ListeSiralama
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_sirala = new System.Windows.Forms.Button();
            this.btn_secim = new System.Windows.Forms.Button();
            this.lsl_elemanlar = new System.Windows.Forms.ListBox();
            this.lsl_sirali = new System.Windows.Forms.ListBox();
            this.lsl_ters = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_sirala
            // 
            this.btn_sirala.Location = new System.Drawing.Point(141, 37);
            this.btn_sirala.Name = "btn_sirala";
            this.btn_sirala.Size = new System.Drawing.Size(94, 117);
            this.btn_sirala.TabIndex = 0;
            this.btn_sirala.Text = "sırala";
            this.btn_sirala.UseVisualStyleBackColor = true;
            this.btn_sirala.Click += new System.EventHandler(this.btn_sirala_Click);
            // 
            // btn_secim
            // 
            this.btn_secim.Location = new System.Drawing.Point(141, 158);
            this.btn_secim.Name = "btn_secim";
            this.btn_secim.Size = new System.Drawing.Size(94, 117);
            this.btn_secim.TabIndex = 1;
            this.btn_secim.Text = "seçimi sırala";
            this.btn_secim.UseVisualStyleBackColor = true;
            this.btn_secim.Click += new System.EventHandler(this.btn_secim_Click);
            // 
            // lsl_elemanlar
            // 
            this.lsl_elemanlar.FormattingEnabled = true;
            this.lsl_elemanlar.Location = new System.Drawing.Point(12, 37);
            this.lsl_elemanlar.Name = "lsl_elemanlar";
            this.lsl_elemanlar.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lsl_elemanlar.Size = new System.Drawing.Size(121, 238);
            this.lsl_elemanlar.TabIndex = 2;
            this.lsl_elemanlar.SelectedIndexChanged += new System.EventHandler(this.lsl_elemanlar_SelectedIndexChanged);
            // 
            // lsl_sirali
            // 
            this.lsl_sirali.FormattingEnabled = true;
            this.lsl_sirali.Location = new System.Drawing.Point(241, 37);
            this.lsl_sirali.Name = "lsl_sirali";
            this.lsl_sirali.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lsl_sirali.Size = new System.Drawing.Size(121, 238);
            this.lsl_sirali.TabIndex = 3;
            this.lsl_sirali.SelectedIndexChanged += new System.EventHandler(this.lsl_sirali_SelectedIndexChanged);
            // 
            // lsl_ters
            // 
            this.lsl_ters.FormattingEnabled = true;
            this.lsl_ters.Location = new System.Drawing.Point(368, 37);
            this.lsl_ters.Name = "lsl_ters";
            this.lsl_ters.Size = new System.Drawing.Size(121, 238);
            this.lsl_ters.TabIndex = 4;
            this.lsl_ters.SelectedIndexChanged += new System.EventHandler(this.lsl_ters_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(7, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "lsl_elemanlar";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(155, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "lsl_sirali";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(281, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "lsl_ters";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 288);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lsl_ters);
            this.Controls.Add(this.lsl_sirali);
            this.Controls.Add(this.lsl_elemanlar);
            this.Controls.Add(this.btn_secim);
            this.Controls.Add(this.btn_sirala);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_sirala;
        private System.Windows.Forms.Button btn_secim;
        private System.Windows.Forms.ListBox lsl_elemanlar;
        private System.Windows.Forms.ListBox lsl_sirali;
        private System.Windows.Forms.ListBox lsl_ters;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

