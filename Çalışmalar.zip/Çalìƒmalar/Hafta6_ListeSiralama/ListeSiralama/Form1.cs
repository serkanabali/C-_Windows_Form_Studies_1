﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListeSiralama
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //dizi oluşturuldu
        string[] elemanlar = new string[] { "bilgisayar", "öğretim", "2", "normal", "(programcılığı)" };

        //form load a dizi atandı
        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (string isim in elemanlar)
            {
                lsl_elemanlar.Items.Add(isim);
            }
        }

        //küçükten büyüge - short / ters - reverse
        private void btn_sirala_Click(object sender, EventArgs e)
        {
            lsl_sirali.Items.Clear();
            lsl_ters.Items.Clear();

            Array.Sort(elemanlar);
            foreach (string isim in elemanlar)
            {
                lsl_sirali.Items.Add(isim);
            }

            Array.Reverse(elemanlar);
            foreach (string isim in elemanlar)
            {
                lsl_ters.Items.Add(isim);
            }
        }

        //form> selectionmode> multiextended
        private void btn_secim_Click(object sender, EventArgs e)
        {
            lsl_sirali.Items.Clear();
            lsl_ters.Items.Clear();
            
            //secili fonksiyonu olusturma
            string[] secili = lsl_elemanlar.SelectedItems.OfType<string>().ToArray();
            
            Array.Sort(secili);
            foreach (string isim in secili)
            {
                lsl_sirali.Items.Add(isim);
            }

            Array.Reverse(secili);
            foreach (string isim in secili)
            {
                lsl_ters.Items.Add(isim);
            }
        }

        private void lsl_elemanlar_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lsl_sirali_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lsl_ters_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
