﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta10_Timer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int sayi = 1;
        Random rastgele = new Random();

        private void timer1_Tick(object sender, EventArgs e)
        {
            /*
            timer1.Interval = 1;
            Console.WriteLine("Selam Timer");
            lbl_yazi.Text = Convert.ToString("sayi" + sayi++);  //sayiyi artırarak yazdır
            */

            //rastgele sayi üret yazdır
            lbl_yazi.Text = Convert.ToString(rastgele.Next());
        }

        private void Form1_Load(object sender, EventArgs e)
        {   
            timer1.Enabled = true;
            lbl_maksimuminteger.Text = int.MaxValue.ToString();
        }

        private void btn_baslat_durdur_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled) //==True
            {
                //timer1.Enabled = false;
                timer1.Stop();
            }
            else
            {
                timer1.Start();
            }
        }
    }
}
