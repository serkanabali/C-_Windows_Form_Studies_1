﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_birlestir1_Click(object sender, EventArgs e)
        {
            List<string> kisiler = lst_kisiler.Items.OfType<string>().ToList();
            List<string> yaslar = lst_yas.Items.OfType<string>().ToList(); ;
            List<string> meslekler = lst_meslek.Items.OfType<string>().ToList(); ;

            Random rastgele = new Random();

            for (int i = 0; i < lst_meslek.Items.Count; i++)
            {
                int kisilerYer = rastgele.Next(kisiler.Count); //adet listeden gelir
                int yaslarYer = rastgele.Next(yaslar.Count);
                int mesleklerYer = rastgele.Next(meslekler.Count);

                lst_birlesim.Items.Add(String.Join("-", kisiler[kisilerYer], yaslar[yaslarYer], meslekler[mesleklerYer]));

                kisiler.Remove(lst_kisiler.Items[kisilerYer].ToString());
                yaslar.RemoveAt(yaslarYer);
                meslekler.RemoveAt(mesleklerYer);
                
            }
            lst_birlesim.Items.Add("-----------------------------------");

            btn_sifirla1.Enabled = true;
            btn_birlestir2.Enabled = false;
        }

        private void btn_birlestir2_Click(object sender, EventArgs e)
        {
            Random rastgele = new Random();

            for (int i = 0; i < lst_meslek.Items.Count; i++)
            {
                int kisilerYer = rastgele.Next(lst_kisiler.Items.Count); //adet listeden gelir
                int yaslarYer = rastgele.Next(lst_yas.Items.Count);
                int mesleklerYer = rastgele.Next(lst_meslek.Items.Count);

                lst_birlesim.Items.Add(String.Join("-", lst_kisiler.Items[kisilerYer], lst_yas.Items[yaslarYer], lst_meslek.Items[mesleklerYer]));

                lst_kisiler.Items.Remove(lst_kisiler.Items[kisilerYer].ToString());
                lst_kisiler.Items.RemoveAt(yaslarYer);
                lst_meslek.Items.RemoveAt(mesleklerYer);

            }
            lst_birlesim.Items.Add("-----------------------------------");

            btn_birlestir1.Enabled = false;
            btn_birlestir2.Enabled = false;
            btn_sifirla2.Enabled = true;
        }

        private void btn_sifirla1_Click(object sender, EventArgs e)
        {
            btn_sifirla1.Enabled = false;
        }

        private void btn_sifirla2_Click(object sender, EventArgs e)
        {
            foreach (string item in lst_birlesim.Items)
            {
                string[] parcali = item.Split('-');

                lst_kisiler.Items.Add(parcali[0]);
                lst_yas.Items.Add(parcali[0]);
                lst_meslek.Items.Add(parcali[0]);
            }

            lst_birlesim.Items.Clear();

            btn_sifirla2.Enabled = false;
            btn_birlestir1.Enabled = true;
            btn_birlestir2.Enabled = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //text_kisiler.Text == "" || text_yas.Text == "" || text_meslek.Text == ""
            if (String.IsNullOrWhiteSpace(text_kisiler.Text) ||
                String.IsNullOrWhiteSpace(text_yas.Text) ||
                String.IsNullOrWhiteSpace(text_meslek.Text))
            {
                MessageBox.Show("textler dolu olmalı");
            }
            else
            {
                lst_kisiler.Items.Add(text_kisiler.Text);
                lst_yas.Items.Add(text_yas.Text);
                lst_meslek.Items.Add(text_meslek.Text);
            }
        }

        private void pictureBox1_MouseDown(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.Violet;
        }
    }
    }
}
