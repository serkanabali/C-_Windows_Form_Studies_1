﻿
namespace Hafta7
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lst_kisiler = new System.Windows.Forms.ListBox();
            this.lst_yas = new System.Windows.Forms.ListBox();
            this.lst_meslek = new System.Windows.Forms.ListBox();
            this.lst_birlesim = new System.Windows.Forms.ListBox();
            this.text_kisiler = new System.Windows.Forms.TextBox();
            this.text_yas = new System.Windows.Forms.TextBox();
            this.text_meslek = new System.Windows.Forms.TextBox();
            this.btn_birlestir1 = new System.Windows.Forms.Button();
            this.btn_birlestir2 = new System.Windows.Forms.Button();
            this.btn_sifirla1 = new System.Windows.Forms.Button();
            this.btn_sifirla2 = new System.Windows.Forms.Button();
            this.btn_ekle = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lst_kisiler
            // 
            this.lst_kisiler.FormattingEnabled = true;
            this.lst_kisiler.Items.AddRange(new object[] {
            "Ayşe",
            "Fatma",
            "Mehmet",
            "Ahme",
            "Ali"});
            this.lst_kisiler.Location = new System.Drawing.Point(12, 41);
            this.lst_kisiler.Name = "lst_kisiler";
            this.lst_kisiler.Size = new System.Drawing.Size(145, 212);
            this.lst_kisiler.TabIndex = 0;
            // 
            // lst_yas
            // 
            this.lst_yas.FormattingEnabled = true;
            this.lst_yas.Items.AddRange(new object[] {
            "30",
            "40",
            "50",
            "20",
            "27"});
            this.lst_yas.Location = new System.Drawing.Point(163, 41);
            this.lst_yas.Name = "lst_yas";
            this.lst_yas.Size = new System.Drawing.Size(84, 212);
            this.lst_yas.TabIndex = 1;
            // 
            // lst_meslek
            // 
            this.lst_meslek.FormattingEnabled = true;
            this.lst_meslek.Items.AddRange(new object[] {
            "Psikolog",
            "Pilot",
            "Mühendis",
            "Yazar",
            "Öğrenci"});
            this.lst_meslek.Location = new System.Drawing.Point(253, 41);
            this.lst_meslek.Name = "lst_meslek";
            this.lst_meslek.Size = new System.Drawing.Size(145, 212);
            this.lst_meslek.TabIndex = 2;
            // 
            // lst_birlesim
            // 
            this.lst_birlesim.FormattingEnabled = true;
            this.lst_birlesim.Location = new System.Drawing.Point(488, 41);
            this.lst_birlesim.Name = "lst_birlesim";
            this.lst_birlesim.Size = new System.Drawing.Size(162, 212);
            this.lst_birlesim.TabIndex = 3;
            // 
            // text_kisiler
            // 
            this.text_kisiler.Location = new System.Drawing.Point(12, 259);
            this.text_kisiler.Name = "text_kisiler";
            this.text_kisiler.Size = new System.Drawing.Size(145, 20);
            this.text_kisiler.TabIndex = 4;
            // 
            // text_yas
            // 
            this.text_yas.Location = new System.Drawing.Point(163, 259);
            this.text_yas.Name = "text_yas";
            this.text_yas.Size = new System.Drawing.Size(84, 20);
            this.text_yas.TabIndex = 5;
            // 
            // text_meslek
            // 
            this.text_meslek.Location = new System.Drawing.Point(253, 259);
            this.text_meslek.Name = "text_meslek";
            this.text_meslek.Size = new System.Drawing.Size(145, 20);
            this.text_meslek.TabIndex = 6;
            // 
            // btn_birlestir1
            // 
            this.btn_birlestir1.Location = new System.Drawing.Point(488, 275);
            this.btn_birlestir1.Name = "btn_birlestir1";
            this.btn_birlestir1.Size = new System.Drawing.Size(78, 33);
            this.btn_birlestir1.TabIndex = 7;
            this.btn_birlestir1.Text = "Birleştir 1";
            this.btn_birlestir1.UseVisualStyleBackColor = true;
            this.btn_birlestir1.Click += new System.EventHandler(this.btn_birlestir1_Click);
            // 
            // btn_birlestir2
            // 
            this.btn_birlestir2.Location = new System.Drawing.Point(572, 275);
            this.btn_birlestir2.Name = "btn_birlestir2";
            this.btn_birlestir2.Size = new System.Drawing.Size(78, 33);
            this.btn_birlestir2.TabIndex = 8;
            this.btn_birlestir2.Text = "Birleştir 2";
            this.btn_birlestir2.UseVisualStyleBackColor = true;
            this.btn_birlestir2.Click += new System.EventHandler(this.btn_birlestir2_Click);
            // 
            // btn_sifirla1
            // 
            this.btn_sifirla1.Enabled = false;
            this.btn_sifirla1.Location = new System.Drawing.Point(404, 236);
            this.btn_sifirla1.Name = "btn_sifirla1";
            this.btn_sifirla1.Size = new System.Drawing.Size(78, 33);
            this.btn_sifirla1.TabIndex = 9;
            this.btn_sifirla1.Text = "Sıfırla 1";
            this.btn_sifirla1.UseVisualStyleBackColor = true;
            this.btn_sifirla1.Click += new System.EventHandler(this.btn_sifirla1_Click);
            // 
            // btn_sifirla2
            // 
            this.btn_sifirla2.Enabled = false;
            this.btn_sifirla2.Location = new System.Drawing.Point(404, 275);
            this.btn_sifirla2.Name = "btn_sifirla2";
            this.btn_sifirla2.Size = new System.Drawing.Size(78, 33);
            this.btn_sifirla2.TabIndex = 10;
            this.btn_sifirla2.Text = "Sıfırla 2";
            this.btn_sifirla2.UseVisualStyleBackColor = true;
            this.btn_sifirla2.Click += new System.EventHandler(this.btn_sifirla2_Click);
            // 
            // btn_ekle
            // 
            this.btn_ekle.Location = new System.Drawing.Point(12, 285);
            this.btn_ekle.Name = "btn_ekle";
            this.btn_ekle.Size = new System.Drawing.Size(386, 23);
            this.btn_ekle.TabIndex = 11;
            this.btn_ekle.Text = "Ekle";
            this.btn_ekle.UseVisualStyleBackColor = true;
            this.btn_ekle.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Enabled = false;
            this.button6.Location = new System.Drawing.Point(12, 12);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(145, 23);
            this.button6.TabIndex = 12;
            this.button6.Text = "Kişiler";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Enabled = false;
            this.button7.Location = new System.Drawing.Point(163, 12);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(84, 23);
            this.button7.TabIndex = 13;
            this.button7.Text = "Yaş";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Enabled = false;
            this.button8.Location = new System.Drawing.Point(253, 12);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(145, 23);
            this.button8.TabIndex = 14;
            this.button8.Text = "Meslek";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Enabled = false;
            this.button9.Location = new System.Drawing.Point(488, 12);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(162, 23);
            this.button9.TabIndex = 15;
            this.button9.Text = "Birleştir";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(404, 86);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(78, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(657, 317);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.btn_ekle);
            this.Controls.Add(this.btn_sifirla2);
            this.Controls.Add(this.btn_sifirla1);
            this.Controls.Add(this.btn_birlestir2);
            this.Controls.Add(this.btn_birlestir1);
            this.Controls.Add(this.text_meslek);
            this.Controls.Add(this.text_yas);
            this.Controls.Add(this.text_kisiler);
            this.Controls.Add(this.lst_birlesim);
            this.Controls.Add(this.lst_meslek);
            this.Controls.Add(this.lst_yas);
            this.Controls.Add(this.lst_kisiler);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_kisiler;
        private System.Windows.Forms.ListBox lst_yas;
        private System.Windows.Forms.ListBox lst_meslek;
        private System.Windows.Forms.ListBox lst_birlesim;
        private System.Windows.Forms.TextBox text_kisiler;
        private System.Windows.Forms.TextBox text_yas;
        private System.Windows.Forms.TextBox text_meslek;
        private System.Windows.Forms.Button btn_birlestir1;
        private System.Windows.Forms.Button btn_birlestir2;
        private System.Windows.Forms.Button btn_sifirla1;
        private System.Windows.Forms.Button btn_sifirla2;
        private System.Windows.Forms.Button btn_ekle;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

