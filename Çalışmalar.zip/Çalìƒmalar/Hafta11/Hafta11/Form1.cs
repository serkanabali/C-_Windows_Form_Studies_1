﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //tekli_saga
        private void button1_Click(object sender, EventArgs e)
        {
            while (lst_ogrenci.SelectedItems.Count > 0)
            {
                lst_katilimci.Items.Add(lst_ogrenci.SelectedItems[0]);
                lst_ogrenci.Items.Remove(lst_ogrenci.SelectedItems[0]);
            }

            /*//Benim Yazdıgım Blok
            string[] secili = lst_ogrenci.SelectedItems.OfType<string>().ToArray();
            Array.Sort(secili);


            foreach (string isim in secili)
            {
                lst_katilimci.Items.Add(isim);
                lst_ogrenci.Items.Remove(isim);
            }
            */
        }

        //tekli_sola
        private void button2_Click(object sender, EventArgs e)
        {
            while (lst_katilimci.SelectedItems.Count > 0)
            {
                lst_ogrenci.Items.Add(lst_katilimci.SelectedItems[0]);
                //lst_katilimci.Items.Remove(lst_katilimci.SelectedItems[0]);                               //1. yol
                lst_katilimci.Items.RemoveAt(lst_katilimci.Items.IndexOf(lst_katilimci.SelectedItems[0]));  //2.yol
            }
        }

        //tum_saga
        private void button3_Click(object sender, EventArgs e)
        {
            lst_katilimci.Items.AddRange(lst_ogrenci.Items);
            lst_ogrenci.Items.Clear();
        }

        //tum_sola
        private void button4_Click(object sender, EventArgs e)
        {
            lst_ogrenci.Items.AddRange(lst_katilimci.Items);
            lst_katilimci.Items.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lst_katilimci.SelectionMode = SelectionMode.MultiExtended;
            lst_ogrenci.SelectionMode = SelectionMode.MultiExtended;
        }

        //form_gecis
        private void form_gecis_Click(object sender, EventArgs e)
        {
            /*
            int gidenSayi = 15;
            Bilgiler.sayi = gidenSayi;
            */
            Bilgiler.sayi += 5;

            Form2 f = new Form2();
            f.Show();
            this.Hide();
            //f.ShowDialog();

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();     //herşeyi (arkada çalışan form1 leri de) kapatır
        }

        private void kapat_Click(object sender, EventArgs e)
        {
            DialogResult sonuc;
            sonuc = MessageBox.Show("kapatmak istediğine emin misin?", "uyarı",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (sonuc == DialogResult.Yes)
            {
                this.Close(); //kapat butonu
            }
        }
    }
}
