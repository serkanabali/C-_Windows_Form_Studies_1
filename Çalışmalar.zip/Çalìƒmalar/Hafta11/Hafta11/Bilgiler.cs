﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hafta11
{
    public static class Bilgiler
    {
        public static int sayi = 30;  //static sınıf, static değişken zorunluluğu
    }
}
