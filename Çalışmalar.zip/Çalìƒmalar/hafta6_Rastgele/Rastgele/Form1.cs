﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rastgele
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //int[] sayilar = new int[] { 1, 2, 3, 4, 5, 6 };

        private void Form1_Load(object sender, EventArgs e)
        {
            /*
            foreach (int mevcut in sayilar)
            {
                listBox1.Items.Add(mevcut);
            }
            */
        }
        private void button1_Click(object sender, EventArgs e)
        {
            /*
            listBox2.Items.Clear();
            listBox3.Items.Clear();

            Random rand = new Random();

            foreach (int mevcut in sayilar)
            {
                listBox2.Items.Add(mevcut);
            }

            foreach (int mevcut in sayilar)
            {
                listBox3.Items.Add(mevcut);
            }
            */
            Random rastgele = new Random();
            int elemansayi = listBox1.Items.Count;

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                int sayi = rastgele.Next(listBox1.Items.Count);

                if (i < elemansayi / 2)
                {
                    listBox2.Items.Add(listBox1.Items[sayi]);
                    listBox1.Items.RemoveAt(sayi);
                }
                else
                {
                    listBox3.Items.Add(listBox1.Items[sayi]);
                    listBox1.Items.RemoveAt(sayi);
                }
            }
           listBox1.Items.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
