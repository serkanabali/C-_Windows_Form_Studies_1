﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Deneme
{
    public partial class Form1 : Form
    {
        List<string> katilimciListesi;
        int katilimciSayisi;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lst_katilimci.SelectionMode = SelectionMode.MultiExtended;
            lst_ogrenci.SelectionMode = SelectionMode.MultiExtended;
        }

        private void tekli_saga_Click(object sender, EventArgs e)
        {
            while (lst_ogrenci.SelectedItems.Count > 0)
            {
                lst_katilimci.Items.Add(lst_ogrenci.SelectedItems[0]);
                lst_ogrenci.Items.Remove(lst_ogrenci.SelectedItems[0]);
            }
        }

        private void tekli_sola_Click(object sender, EventArgs e)
        {
            while(lst_katilimci.SelectedItems.Count > 0)
            {
                lst_ogrenci.Items.Add(lst_katilimci.SelectedItems[0]);
                lst_katilimci.Items.RemoveAt(lst_katilimci.Items.IndexOf(lst_katilimci.SelectedItems[0]));
            }
        }

        private void tum_saga_Click(object sender, EventArgs e)
        {
            lst_katilimci.Items.AddRange(lst_ogrenci.Items);
            lst_ogrenci.Items.Clear();
        }

        private void tum_sola_Click(object sender, EventArgs e)
        {
            lst_ogrenci.Items.AddRange(lst_katilimci.Items);
            lst_katilimci.Items.Clear();
        }

        private void form_gecis_Click(object sender, EventArgs e)
        {
            katilimciListesi = lst_katilimci.Items.OfType<string>().ToList();
            katilimciSayisi = lst_katilimci.Items.Count;

            Bilgiler.setKatilimciListesi(katilimciSayisi);
            Bilgiler.setKatilimciListesi(katilimciListesi);

            Form2 f = new Form2();
            f.Show();
            this.Hide();
            //f.ShowDialog();
        }

        private void kapat_Click(object sender, EventArgs e)
        {
            DialogResult sonuc;
            sonuc = MessageBox.Show("kapatmak istediğine emin misin?", "uyarı",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (sonuc == DialogResult.Yes)
            {
                this.Close(); //kapat butonu
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();     //herşeyi (arkada çalışan form1 leri de) kapatır
        }
    }
}
