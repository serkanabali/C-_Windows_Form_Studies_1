﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Deneme
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form f = Application.OpenForms["Form1"];    //açık olan Form1 i alır
            f.Show();   //gizlenmiş Form1 i gösterir
        }

        private void btn_geridon_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        List<string> liste;
        int sayi;

        private void Form2_Load(object sender, EventArgs e)
        {
            liste = Bilgiler.getKatilimciListesi();
            sayi = Bilgiler.getKatilimciSayisi();

            foreach (string item in liste)
            {
                lst_katilimcilar.Items.Add(item);
            }
            lbl_sayi.Text = sayi.ToString();
        }
    }
}
