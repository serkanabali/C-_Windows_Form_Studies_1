﻿
namespace Deneme
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_ogrenci = new System.Windows.Forms.ListBox();
            this.form_gecis = new System.Windows.Forms.Button();
            this.tekli_saga = new System.Windows.Forms.Button();
            this.tekli_sola = new System.Windows.Forms.Button();
            this.tum_saga = new System.Windows.Forms.Button();
            this.tum_sola = new System.Windows.Forms.Button();
            this.lst_katilimci = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.kapat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lst_ogrenci
            // 
            this.lst_ogrenci.FormattingEnabled = true;
            this.lst_ogrenci.Items.AddRange(new object[] {
            "Ayşe",
            "Fatma",
            "Hayriye",
            "Ahmet",
            "Mehmet",
            "Veli",
            "Ali",
            "Can",
            "Zeynep",
            "Elif",
            "Serkan",
            "Hakan"});
            this.lst_ogrenci.Location = new System.Drawing.Point(12, 32);
            this.lst_ogrenci.Name = "lst_ogrenci";
            this.lst_ogrenci.Size = new System.Drawing.Size(120, 212);
            this.lst_ogrenci.TabIndex = 3;
            // 
            // form_gecis
            // 
            this.form_gecis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.form_gecis.Location = new System.Drawing.Point(12, 250);
            this.form_gecis.Name = "form_gecis";
            this.form_gecis.Size = new System.Drawing.Size(120, 50);
            this.form_gecis.TabIndex = 9;
            this.form_gecis.Text = "Katılımcıları İncele";
            this.form_gecis.UseVisualStyleBackColor = true;
            this.form_gecis.Click += new System.EventHandler(this.form_gecis_Click);
            // 
            // tekli_saga
            // 
            this.tekli_saga.Location = new System.Drawing.Point(138, 32);
            this.tekli_saga.Name = "tekli_saga";
            this.tekli_saga.Size = new System.Drawing.Size(75, 23);
            this.tekli_saga.TabIndex = 10;
            this.tekli_saga.Text = ">";
            this.tekli_saga.UseVisualStyleBackColor = true;
            this.tekli_saga.Click += new System.EventHandler(this.tekli_saga_Click);
            // 
            // tekli_sola
            // 
            this.tekli_sola.Location = new System.Drawing.Point(138, 61);
            this.tekli_sola.Name = "tekli_sola";
            this.tekli_sola.Size = new System.Drawing.Size(75, 23);
            this.tekli_sola.TabIndex = 11;
            this.tekli_sola.Text = "<";
            this.tekli_sola.UseVisualStyleBackColor = true;
            this.tekli_sola.Click += new System.EventHandler(this.tekli_sola_Click);
            // 
            // tum_saga
            // 
            this.tum_saga.Location = new System.Drawing.Point(138, 192);
            this.tum_saga.Name = "tum_saga";
            this.tum_saga.Size = new System.Drawing.Size(75, 23);
            this.tum_saga.TabIndex = 12;
            this.tum_saga.Text = ">>";
            this.tum_saga.UseVisualStyleBackColor = true;
            this.tum_saga.Click += new System.EventHandler(this.tum_saga_Click);
            // 
            // tum_sola
            // 
            this.tum_sola.Location = new System.Drawing.Point(138, 221);
            this.tum_sola.Name = "tum_sola";
            this.tum_sola.Size = new System.Drawing.Size(75, 23);
            this.tum_sola.TabIndex = 13;
            this.tum_sola.Text = "<<";
            this.tum_sola.UseVisualStyleBackColor = true;
            this.tum_sola.Click += new System.EventHandler(this.tum_sola_Click);
            // 
            // lst_katilimci
            // 
            this.lst_katilimci.FormattingEnabled = true;
            this.lst_katilimci.Location = new System.Drawing.Point(219, 32);
            this.lst_katilimci.Name = "lst_katilimci";
            this.lst_katilimci.Size = new System.Drawing.Size(120, 212);
            this.lst_katilimci.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "Öğrenci Listesi";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(215, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "Katılımcı Listesi";
            // 
            // kapat
            // 
            this.kapat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kapat.Location = new System.Drawing.Point(219, 250);
            this.kapat.Name = "kapat";
            this.kapat.Size = new System.Drawing.Size(120, 50);
            this.kapat.TabIndex = 17;
            this.kapat.Text = "Kapat";
            this.kapat.UseVisualStyleBackColor = true;
            this.kapat.Click += new System.EventHandler(this.kapat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 323);
            this.Controls.Add(this.kapat);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lst_katilimci);
            this.Controls.Add(this.tum_sola);
            this.Controls.Add(this.tum_saga);
            this.Controls.Add(this.tekli_sola);
            this.Controls.Add(this.tekli_saga);
            this.Controls.Add(this.form_gecis);
            this.Controls.Add(this.lst_ogrenci);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_ogrenci;
        private System.Windows.Forms.Button form_gecis;
        private System.Windows.Forms.Button tekli_saga;
        private System.Windows.Forms.Button tekli_sola;
        private System.Windows.Forms.Button tum_saga;
        private System.Windows.Forms.Button tum_sola;
        private System.Windows.Forms.ListBox lst_katilimci;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button kapat;
    }
}

