﻿
namespace Deneme
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_katilimcilar = new System.Windows.Forms.ListBox();
            this.btn_geridon = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_sayi = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lst_katilimcilar
            // 
            this.lst_katilimcilar.FormattingEnabled = true;
            this.lst_katilimcilar.Location = new System.Drawing.Point(12, 12);
            this.lst_katilimcilar.Name = "lst_katilimcilar";
            this.lst_katilimcilar.Size = new System.Drawing.Size(120, 95);
            this.lst_katilimcilar.TabIndex = 3;
            // 
            // btn_geridon
            // 
            this.btn_geridon.Location = new System.Drawing.Point(12, 113);
            this.btn_geridon.Name = "btn_geridon";
            this.btn_geridon.Size = new System.Drawing.Size(120, 27);
            this.btn_geridon.TabIndex = 4;
            this.btn_geridon.Text = "Geri Dön";
            this.btn_geridon.UseVisualStyleBackColor = true;
            this.btn_geridon.Click += new System.EventHandler(this.btn_geridon_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(138, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 26);
            this.label1.TabIndex = 5;
            this.label1.Text = "Katılımcılar: ";
            // 
            // lbl_sayi
            // 
            this.lbl_sayi.AutoSize = true;
            this.lbl_sayi.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_sayi.Location = new System.Drawing.Point(275, 12);
            this.lbl_sayi.Name = "lbl_sayi";
            this.lbl_sayi.Size = new System.Drawing.Size(24, 26);
            this.lbl_sayi.TabIndex = 6;
            this.lbl_sayi.Text = "_";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(360, 181);
            this.Controls.Add(this.lbl_sayi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_geridon);
            this.Controls.Add(this.lst_katilimcilar);
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_katilimcilar;
        private System.Windows.Forms.Button btn_geridon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_sayi;
    }
}