﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deneme
{
    public static class Bilgiler
    {
        static int sayi;
        static List<string> katilimcilar = new List<string>();

        public static int getKatilimciSayisi()
        {
            return sayi;
        }
        public static void setKatilimciSayisi(int KatilimciSayisi)
        {
            sayi = KatilimciSayisi;
        }
        public static List<string> getKatilimciListesi()
        {
            return katilimcilar;
        }
        public static void setKatilimciListesi(List<string> liste)
        {
            katilimcilar = liste;
        }
    }
}
