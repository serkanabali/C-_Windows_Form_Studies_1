﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int sayi1 = 1;
        int sayi2 = 1;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        //ABS [KAREKÖK]
        private void button1_Click(object sender, EventArgs e)
        {
            sayi1 = int.Parse(textBox2.Text);
            sayi2 = Convert.ToInt32(textBox3.Text);

            textBox1.Text = Math.Abs(sayi1).ToString();

        }

        //SİN
        private void button2_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox2.Text, out sayi1);
            //tryParse donusum basarısızsa "0" verir - her türlü dönüştürmeye çalışır
            //parse de hata verir
            int.TryParse(textBox3.Text, out sayi2);

            textBox1.Text = Math.Sin(sayi1).ToString();
        }

        //SQRT
        private void button3_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox2.Text, out sayi1);
            int.TryParse(textBox3.Text, out sayi2);

            textBox1.Text = Math.Sqrt(sayi1).ToString();
        }

        //POW
        private void button4_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox2.Text, out sayi1);
            int.TryParse(textBox3.Text, out sayi2);

            textBox1.Text = Math.Pow(sayi1, sayi2).ToString();
        }

        //MAX
        private void button5_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox2.Text, out sayi1);
            int.TryParse(textBox3.Text, out sayi2);

            textBox1.Text = Math.Max(sayi1, sayi2).ToString();
        }

        //MİN
        private void button6_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox2.Text, out sayi1);
            int.TryParse(textBox3.Text, out sayi2);

            textBox1.Text = Math.Min(sayi1, sayi2).ToString();
        }

        //FLOOR
        private void button7_Click(object sender, EventArgs e)
        {
            decimal i = sayi1;
            decimal.TryParse(textBox2.Text, out i);

            textBox1.Text = Math.Floor(i).ToString();
        }

        //ROUND
        private void button8_Click(object sender, EventArgs e)
        {
            decimal i = sayi1;
            decimal.TryParse(textBox2.Text, out i);

            textBox1.Text = Math.Round(i).ToString();
        }

        //CEİLİNG
        private void button9_Click(object sender, EventArgs e)
        {
            decimal i = sayi1;

            decimal.TryParse(textBox2.Text, out i);
            int.TryParse(textBox3.Text, out sayi2);

            textBox1.Text = Math.Ceiling(i).ToString();
        }

        //İKİNCİ SAYFA----------------------

        //INDEXOF
        private void button10_Click(object sender, EventArgs e)
        {
            string yazi = textBox4.Text;
            string parametre1 = textBox5.Text;
            string parametre2 = textBox6.Text;

            int sonuc = yazi.IndexOf(textBox5.Text);
            label7.Text = Convert.ToString(sonuc);


        }

        //LASTINDEXOF
        private void button13_Click(object sender, EventArgs e)
        {
            string yazi = textBox4.Text;
            string parametre1 = textBox5.Text;
            string parametre2 = textBox6.Text;

            //buyuk kucuk harfe duyarlı
            int sonuc = yazi.LastIndexOf(textBox5.Text);
            label7.Text = Convert.ToString(sonuc);
        }

        //ToLower
        private void button11_Click(object sender, EventArgs e)
        {
            string yazi = textBox4.Text;
            string parametre1 = textBox5.Text;
            string parametre2 = textBox6.Text;

            string sonuc = yazi.ToLower();
            label7.Text = Convert.ToString(sonuc);
        }

        //ELEMENT AT
        private void button16_Click(object sender, EventArgs e)
        {
            string yazi = textBox4.Text;
            string parametre1 = textBox5.Text;
            string parametre2 = textBox6.Text;

            char sonuc = yazi.ElementAt(Convert.ToInt32(parametre1));
            label7.Text = Convert.ToString(sonuc);
        }

        //REPLACE - yazının belli kısmını değiştirir
        private void button17_Click(object sender, EventArgs e)
        {
            string yazi = textBox4.Text;
            string parametre1 = textBox5.Text;
            string parametre2 = textBox6.Text;

            string sonuc = yazi.Replace(parametre1, parametre2);
            label7.Text = Convert.ToString(sonuc);
        }

        //REMOVE
        private void button15_Click(object sender, EventArgs e)
        {
            string yazi = textBox4.Text;
            string parametre1 = textBox5.Text;
            string parametre2 = textBox6.Text;

            string sonuc = yazi.Remove(Convert.ToInt32(parametre1));
            label7.Text = sonuc;
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }
        /*
//SUBSTRİNG
private void button14_Click(object sender, EventArgs e)
{
   string yazi = textBox4.Text;
   string parametre1 = textBox5.Text;
   string parametre2 = textBox6.Text;

   string sonuc = yazi.Substring();
   label7.Text = Convert.ToString(sonuc);
}*/
    }
}