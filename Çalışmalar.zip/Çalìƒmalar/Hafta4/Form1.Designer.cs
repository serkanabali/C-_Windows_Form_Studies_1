﻿
namespace Hafta4
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_sonuc = new System.Windows.Forms.Label();
            this.txt_sayi = new System.Windows.Forms.TextBox();
            this.btn_hesapla = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_sonuc = new System.Windows.Forms.TextBox();
            this.cb_dortislem = new System.Windows.Forms.ComboBox();
            this.btn_hesapla2 = new System.Windows.Forms.Button();
            this.txt_sayi2 = new System.Windows.Forms.TextBox();
            this.txt_sayi1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pb_kutu = new System.Windows.Forms.PictureBox();
            this.lbl_KeyData = new System.Windows.Forms.Label();
            this.lbl_KeyValue = new System.Windows.Forms.Label();
            this.lbl_KeyCode = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kutu)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(26, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sayı";
            // 
            // lbl_sonuc
            // 
            this.lbl_sonuc.AutoSize = true;
            this.lbl_sonuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_sonuc.Location = new System.Drawing.Point(26, 111);
            this.lbl_sonuc.Name = "lbl_sonuc";
            this.lbl_sonuc.Size = new System.Drawing.Size(123, 39);
            this.lbl_sonuc.TabIndex = 1;
            this.lbl_sonuc.Text = "Sonuc:";
            // 
            // txt_sayi
            // 
            this.txt_sayi.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_sayi.Location = new System.Drawing.Point(116, 28);
            this.txt_sayi.Name = "txt_sayi";
            this.txt_sayi.Size = new System.Drawing.Size(141, 45);
            this.txt_sayi.TabIndex = 2;
            // 
            // btn_hesapla
            // 
            this.btn_hesapla.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_hesapla.Location = new System.Drawing.Point(32, 184);
            this.btn_hesapla.Name = "btn_hesapla";
            this.btn_hesapla.Size = new System.Drawing.Size(154, 53);
            this.btn_hesapla.TabIndex = 3;
            this.btn_hesapla.Text = "Hesapla";
            this.btn_hesapla.UseVisualStyleBackColor = true;
            this.btn_hesapla.Click += new System.EventHandler(this.btn_hesapla_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_sonuc);
            this.groupBox1.Controls.Add(this.cb_dortislem);
            this.groupBox1.Controls.Add(this.btn_hesapla2);
            this.groupBox1.Controls.Add(this.txt_sayi2);
            this.groupBox1.Controls.Add(this.txt_sayi1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(275, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(543, 268);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // txt_sonuc
            // 
            this.txt_sonuc.Enabled = false;
            this.txt_sonuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_sonuc.Location = new System.Drawing.Point(12, 187);
            this.txt_sonuc.Name = "txt_sonuc";
            this.txt_sonuc.Size = new System.Drawing.Size(266, 45);
            this.txt_sonuc.TabIndex = 8;
            // 
            // cb_dortislem
            // 
            this.cb_dortislem.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cb_dortislem.FormattingEnabled = true;
            this.cb_dortislem.Items.AddRange(new object[] {
            "+",
            "-",
            "*",
            "/"});
            this.cb_dortislem.Location = new System.Drawing.Point(306, 15);
            this.cb_dortislem.Name = "cb_dortislem";
            this.cb_dortislem.Size = new System.Drawing.Size(178, 46);
            this.cb_dortislem.TabIndex = 5;
            this.cb_dortislem.Text = "Seçin...";
            // 
            // btn_hesapla2
            // 
            this.btn_hesapla2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_hesapla2.Location = new System.Drawing.Point(318, 172);
            this.btn_hesapla2.Name = "btn_hesapla2";
            this.btn_hesapla2.Size = new System.Drawing.Size(166, 53);
            this.btn_hesapla2.TabIndex = 5;
            this.btn_hesapla2.Text = "Hesapla";
            this.btn_hesapla2.UseVisualStyleBackColor = true;
            this.btn_hesapla2.Click += new System.EventHandler(this.btn_hesapla2_Click);
            // 
            // txt_sayi2
            // 
            this.txt_sayi2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_sayi2.Location = new System.Drawing.Point(115, 92);
            this.txt_sayi2.Name = "txt_sayi2";
            this.txt_sayi2.Size = new System.Drawing.Size(163, 45);
            this.txt_sayi2.TabIndex = 6;
            // 
            // txt_sayi1
            // 
            this.txt_sayi1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_sayi1.Location = new System.Drawing.Point(115, 16);
            this.txt_sayi1.Name = "txt_sayi1";
            this.txt_sayi1.Size = new System.Drawing.Size(163, 45);
            this.txt_sayi1.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(6, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 39);
            this.label2.TabIndex = 5;
            this.label2.Text = "Sayı1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(6, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 39);
            this.label3.TabIndex = 6;
            this.label3.Text = "Sayı2";
            // 
            // pb_kutu
            // 
            this.pb_kutu.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pb_kutu.Location = new System.Drawing.Point(171, 104);
            this.pb_kutu.Name = "pb_kutu";
            this.pb_kutu.Size = new System.Drawing.Size(86, 53);
            this.pb_kutu.TabIndex = 9;
            this.pb_kutu.TabStop = false;
            // 
            // lbl_KeyData
            // 
            this.lbl_KeyData.AutoSize = true;
            this.lbl_KeyData.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_KeyData.Location = new System.Drawing.Point(22, 350);
            this.lbl_KeyData.Name = "lbl_KeyData";
            this.lbl_KeyData.Size = new System.Drawing.Size(148, 39);
            this.lbl_KeyData.TabIndex = 9;
            this.lbl_KeyData.Text = "KeyData";
            // 
            // lbl_KeyValue
            // 
            this.lbl_KeyValue.AutoSize = true;
            this.lbl_KeyValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_KeyValue.Location = new System.Drawing.Point(22, 409);
            this.lbl_KeyValue.Name = "lbl_KeyValue";
            this.lbl_KeyValue.Size = new System.Drawing.Size(164, 39);
            this.lbl_KeyValue.TabIndex = 10;
            this.lbl_KeyValue.Text = "KeyValue";
            // 
            // lbl_KeyCode
            // 
            this.lbl_KeyCode.AutoSize = true;
            this.lbl_KeyCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_KeyCode.Location = new System.Drawing.Point(22, 467);
            this.lbl_KeyCode.Name = "lbl_KeyCode";
            this.lbl_KeyCode.Size = new System.Drawing.Size(158, 39);
            this.lbl_KeyCode.TabIndex = 11;
            this.lbl_KeyCode.Text = "KeyCode";
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.DarkOrange;
            this.ClientSize = new System.Drawing.Size(886, 531);
            this.Controls.Add(this.lbl_KeyData);
            this.Controls.Add(this.lbl_KeyValue);
            this.Controls.Add(this.lbl_KeyCode);
            this.Controls.Add(this.pb_kutu);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_hesapla);
            this.Controls.Add(this.txt_sayi);
            this.Controls.Add(this.lbl_sonuc);
            this.Controls.Add(this.label1);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_kutu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_sonuc;
        private System.Windows.Forms.TextBox txt_sayi;
        private System.Windows.Forms.Button btn_hesapla;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_hesapla2;
        private System.Windows.Forms.TextBox txt_sayi2;
        private System.Windows.Forms.TextBox txt_sayi1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_dortislem;
        private System.Windows.Forms.TextBox txt_sonuc;
        private System.Windows.Forms.PictureBox pb_kutu;
        private System.Windows.Forms.Label lbl_KeyData;
        private System.Windows.Forms.Label lbl_KeyValue;
        private System.Windows.Forms.Label lbl_KeyCode;
    }
}

