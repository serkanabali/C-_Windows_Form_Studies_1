﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_hesapla_Click(object sender, EventArgs e)
        {
            int sayi = 0;
            bool sonuc = int.TryParse (txt_sayi.Text, out sayi);
            int.TryParse (txt_sayi.Text, out sayi);

            if (sonuc)
            {

                if (sayi > 0)
                {
                    //degiskenle string kullanma 1
                    lbl_sonuc.Text = "Sonuc: " + sayi + " pozitiftir";
                }

                else if (sayi < 0)
                {
                    //degiskenle string kullanma 2
                    lbl_sonuc.Text = String.Format("Sonuc: {0} negatiftir", sayi);
                }

                else
                {
                    //degiskenle string kullanma 3
                    lbl_sonuc.Text = String.Concat("Sonuc: ", sayi, " sıfıra eşittir");
                }

            }
            else
            {
                lbl_sonuc.Text = String.Join("---", "hatalı", "giriş", " yaptınız");
            }


        }

        //FORMDA COMBO BOX İÇİNE +-*/ ATANDI
        private void btn_hesapla2_Click(object sender, EventArgs e)
        {
            int sayi1 = 0;
            int sayi2 = 0;

            int.TryParse(txt_sayi1.Text, out sayi1);
            int.TryParse(txt_sayi2.Text, out sayi2);

            //DORT İSLEM YAPMA
            char islem = Convert.ToChar(cb_dortislem.SelectedItem);
            int sonuc = 0;

                switch (islem)
            {
                case '+':
                   sonuc = sayi1 + sayi2;
                    break;
                
                case '-':
                    sonuc = sayi1 - sayi2;
                    break;
                
                case '*':
                    sonuc = sayi1 * sayi2;
                    break;
                
                case '/':
                    sonuc = sayi1 / sayi2;
                    break;
            }

            txt_sonuc.Text = sonuc.ToString();

        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char yon = e.KeyChar;

            switch (yon)
            {
                case 'w':
                case 'W':
                    pb_kutu.Top -= 50;
                    break;
                case 'a':
                case 'A':
                    pb_kutu.Left -= 50;
                    break;
                case 's':
                case 'S':
                    pb_kutu.Top += 50;
                    break;
                case 'd':
                case 'D':
                    pb_kutu.Left += 50;
                    break;
            }

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            lbl_KeyCode.Text = e.KeyCode.ToString();
            lbl_KeyData.Text = e.KeyData.ToString();
            lbl_KeyValue.Text = e.KeyValue.ToString();
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            lbl_KeyCode.Text = "KeyCode";
            lbl_KeyData.Text = "KeyData";
            lbl_KeyValue.Text = "KeyValue";
        }
    }
}
