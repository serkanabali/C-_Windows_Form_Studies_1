﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string hareketYonu = "";

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }
        
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char yon = e.KeyChar;
            //label1.Text = yon.ToString();
            //tum tusları gormek ıcın keydata[keydown olayı gerekli]

                switch (yon)
                {
                    case 'w':
                    case 'W':
                        hareketYonu="yukari";
                        break;
                    case 'a':
                    case 'A':
                        hareketYonu="sola";
                        break;
                    case 's':
                    case 'S':
                        hareketYonu = "asagi"; ;
                        break;
                    case 'd':
                    case 'D':
                        hareketYonu = "saga"; ;
                        break;
                default:
                    hareketYonu = "";
                    break;
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
                
        }
        
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            label1.Text = e.KeyData.ToString();
        }
       
        private void timer1_Tick(object sender, EventArgs e)
        {
            switch (hareketYonu)
            {
                case "yukari":
                    pictureBox1.Top -= 1;
                    break;
                case "saga":
                    pictureBox1.Left += 1;
                    break;
                case "asagi":
                    pictureBox1.Top += 1;
                    break;
                case "sola":
                    pictureBox1.Left -= 1;
                    break;
            }
        }
    }
}
