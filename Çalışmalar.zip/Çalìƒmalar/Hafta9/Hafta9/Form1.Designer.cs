﻿
namespace Hafta9
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_sayi1 = new System.Windows.Forms.Label();
            this.lbl_sayi2 = new System.Windows.Forms.Label();
            this.btn_islemYap = new System.Windows.Forms.Button();
            this.txt_sayi1 = new System.Windows.Forms.TextBox();
            this.txt_sayi2 = new System.Windows.Forms.TextBox();
            this.lst_elemanlar = new System.Windows.Forms.ListBox();
            this.btn_renkDegistir = new System.Windows.Forms.Button();
            this.lst_sayilar = new System.Windows.Forms.ListBox();
            this.btn_dagıt = new System.Windows.Forms.Button();
            this.cb_elemanlar = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_sayi1
            // 
            this.lbl_sayi1.AutoSize = true;
            this.lbl_sayi1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_sayi1.Location = new System.Drawing.Point(12, 9);
            this.lbl_sayi1.Name = "lbl_sayi1";
            this.lbl_sayi1.Size = new System.Drawing.Size(73, 26);
            this.lbl_sayi1.TabIndex = 0;
            this.lbl_sayi1.Text = "Sayı 1";
            // 
            // lbl_sayi2
            // 
            this.lbl_sayi2.AutoSize = true;
            this.lbl_sayi2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_sayi2.Location = new System.Drawing.Point(12, 35);
            this.lbl_sayi2.Name = "lbl_sayi2";
            this.lbl_sayi2.Size = new System.Drawing.Size(73, 26);
            this.lbl_sayi2.TabIndex = 1;
            this.lbl_sayi2.Text = "Sayı 2";
            // 
            // btn_islemYap
            // 
            this.btn_islemYap.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_islemYap.Location = new System.Drawing.Point(12, 64);
            this.btn_islemYap.Name = "btn_islemYap";
            this.btn_islemYap.Size = new System.Drawing.Size(191, 43);
            this.btn_islemYap.TabIndex = 2;
            this.btn_islemYap.Text = "İşlem Yap";
            this.btn_islemYap.UseVisualStyleBackColor = true;
            this.btn_islemYap.Click += new System.EventHandler(this.btn_islemYap_Click);
            // 
            // txt_sayi1
            // 
            this.txt_sayi1.Location = new System.Drawing.Point(91, 15);
            this.txt_sayi1.Name = "txt_sayi1";
            this.txt_sayi1.Size = new System.Drawing.Size(112, 20);
            this.txt_sayi1.TabIndex = 3;
            // 
            // txt_sayi2
            // 
            this.txt_sayi2.Location = new System.Drawing.Point(91, 41);
            this.txt_sayi2.Name = "txt_sayi2";
            this.txt_sayi2.Size = new System.Drawing.Size(112, 20);
            this.txt_sayi2.TabIndex = 4;
            // 
            // lst_elemanlar
            // 
            this.lst_elemanlar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lst_elemanlar.FormattingEnabled = true;
            this.lst_elemanlar.ItemHeight = 25;
            this.lst_elemanlar.Location = new System.Drawing.Point(209, 9);
            this.lst_elemanlar.Name = "lst_elemanlar";
            this.lst_elemanlar.Size = new System.Drawing.Size(142, 104);
            this.lst_elemanlar.TabIndex = 5;
            // 
            // btn_renkDegistir
            // 
            this.btn_renkDegistir.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_renkDegistir.Location = new System.Drawing.Point(12, 113);
            this.btn_renkDegistir.Name = "btn_renkDegistir";
            this.btn_renkDegistir.Size = new System.Drawing.Size(191, 43);
            this.btn_renkDegistir.TabIndex = 6;
            this.btn_renkDegistir.Text = "Değiştir";
            this.btn_renkDegistir.UseVisualStyleBackColor = true;
            this.btn_renkDegistir.Click += new System.EventHandler(this.btn_renkDegistir_Click);
            // 
            // lst_sayilar
            // 
            this.lst_sayilar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lst_sayilar.FormattingEnabled = true;
            this.lst_sayilar.ItemHeight = 16;
            this.lst_sayilar.Items.AddRange(new object[] {
            "1",
            "11",
            "21",
            "31",
            "41",
            "51",
            "61",
            "71",
            "81",
            "91"});
            this.lst_sayilar.Location = new System.Drawing.Point(357, 9);
            this.lst_sayilar.Name = "lst_sayilar";
            this.lst_sayilar.Size = new System.Drawing.Size(142, 164);
            this.lst_sayilar.TabIndex = 7;
            // 
            // btn_dagıt
            // 
            this.btn_dagıt.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_dagıt.Location = new System.Drawing.Point(12, 162);
            this.btn_dagıt.Name = "btn_dagıt";
            this.btn_dagıt.Size = new System.Drawing.Size(191, 43);
            this.btn_dagıt.TabIndex = 8;
            this.btn_dagıt.Text = "Dağıt";
            this.btn_dagıt.UseVisualStyleBackColor = true;
            this.btn_dagıt.Click += new System.EventHandler(this.btn_dagıt_Click);
            // 
            // cb_elemanlar
            // 
            this.cb_elemanlar.FormattingEnabled = true;
            this.cb_elemanlar.Location = new System.Drawing.Point(357, 184);
            this.cb_elemanlar.Name = "cb_elemanlar";
            this.cb_elemanlar.Size = new System.Drawing.Size(142, 21);
            this.cb_elemanlar.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 218);
            this.Controls.Add(this.cb_elemanlar);
            this.Controls.Add(this.btn_dagıt);
            this.Controls.Add(this.lst_sayilar);
            this.Controls.Add(this.btn_renkDegistir);
            this.Controls.Add(this.lst_elemanlar);
            this.Controls.Add(this.txt_sayi2);
            this.Controls.Add(this.txt_sayi1);
            this.Controls.Add(this.btn_islemYap);
            this.Controls.Add(this.lbl_sayi2);
            this.Controls.Add(this.lbl_sayi1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_sayi1;
        private System.Windows.Forms.Label lbl_sayi2;
        private System.Windows.Forms.Button btn_islemYap;
        private System.Windows.Forms.TextBox txt_sayi1;
        private System.Windows.Forms.TextBox txt_sayi2;
        private System.Windows.Forms.ListBox lst_elemanlar;
        private System.Windows.Forms.Button btn_renkDegistir;
        private System.Windows.Forms.ListBox lst_sayilar;
        private System.Windows.Forms.Button btn_dagıt;
        private System.Windows.Forms.ComboBox cb_elemanlar;
    }
}

