﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_islemYap_Click(object sender, EventArgs e)
        {
            
            int sayiBir, sayiIki;
            int.TryParse(txt_sayi1.Text, out sayiBir);
            int.TryParse(txt_sayi2.Text, out sayiIki);
            
            lst_elemanlar.Items.Add(maksimum(sayiBir, sayiIki)); ;
            
            //Alternatif Yöntem
            //int sonuc = maksimum(sayiBir, sayiIki);
            //lst_elemanlar.Items.Add(sonuc);

            int faktoriyel = Faktöriyel();

            lst_elemanlar.Items.Add(faktoriyel);
        }

        private int maksimum(int sayi1, int sayi2)
        {
            if (sayi1 > sayi2)
            {
                return sayi1;
            }
            else
            {
                return sayi2;
            }
        }

        //6 Faktöriyel
        private int Faktöriyel()
        {
            int sonuc = 1;
            for (int i = 6; i >= 1; i--)
            {
                sonuc *= i;
            }
            return sonuc;
        }

        private void btn_renkDegistir_Click(object sender, EventArgs e)
        {
            RenkDegistir(txt_sayi1);
            RenkDegistir(lbl_sayi2);
            ArkaplanDegistir(lst_elemanlar);
            Dagit();
            //KelimeBol("Bilgisayar Programcılığı İkinci Sınıf",' ');   //ikinci yontem için
        }

        private void RenkDegistir(TextBox txt)
        {
            txt.BackColor = Color.Red;
            txt.ForeColor = Color.FromArgb(6, 254, 250);    //Text Color
        }

        private void RenkDegistir(Label lbl)
        {
            lbl.BackColor = Color.Blue;
            lbl.ForeColor = Color.FromArgb(28, 127, 101);
        }

        private void ArkaplanDegistir(Control nesne)    //control, görsel karşılığı olan nesnedir
        {
            nesne.BackColor = Color.FromArgb(50, 243, 60);
        }

        private void btn_dagıt_Click(object sender, EventArgs e)
        {
            Dagit();
            //KelimeBol();  //birinci yontem için
        }
        
        private void Dagit()
        {
            cb_elemanlar.Items.Clear();

            Random rnd = new Random();

            List<object> liste = lst_sayilar.Items.OfType<object>().ToList();

            for (int i = 1; i <= 5; i++)
            {
                int sayi = rnd.Next(liste.Count);
                cb_elemanlar.Items.Add(liste[sayi]);
                liste.Remove(liste[sayi]);
            }
        }

        /*//ikinci yontem
        private void KelimeBol(string kelime, char ayrac)
        {
            string[] kelimeler = kelime.Split(ayrac);

            foreach (var eleman in kelimeler)
            {
                lst_elemanlar.Items.Add(kelime);
            }
        }
        */

        /*//birinci yontem
        private void KelimeBol()
        {
            string[] kelimeler = "Görsel, Programlama, Normal, Öğretim".Split('-');

            foreach (var kelime in kelimeler)
            {
                lst_elemanlar.Items.Add(kelime);
            }
        }
        */

        private void KelimeBol(string kelime, char ayrac, ComboBox kombo)
        {
            string[] kelimeler = kelime.Split(ayrac);

            foreach (var eleman in kelimeler)
            {
                lst_elemanlar.Items.Add(kelime);
            }
        }
}
