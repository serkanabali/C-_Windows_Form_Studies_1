﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] sayilar = new int[] { 10, 20, 30, 40, 50 };
        List<string> programlar = new List<string>();


        private void Form1_Load(object sender, EventArgs e)
        {
            programlar.Add("bilgisayar programcılığı");
            programlar.Add("bilgisayar teknolojisi");
            programlar.Add("bilişim güvenliği teknolojisi");
            programlar.Add("web tasarımı ve kodlama");
            programlar.Insert(0,"bilgisayar destekli tasarım ve animasyon");    //0. indise eklendi - diğerlerini kaydırır
        }

        private void btn_for_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < 6; i++)    //for + "2 tab"
            {
                lst_elemanlar.Items.Add(String.Format("{0}.sayi", i)); //format = string i bozmadan kullanma
            }
        }

        private void btn_foreach_Click(object sender, EventArgs e)
        {
            int i = 1;
            foreach (string program in programlar)
            {
                //lst_elemanlar.Items.Add(program);
                lst_elemanlar.Items.Add(string.Concat(i++, program));   //önce yazar sonra artırır
            }
        }

        private void btn_while_Click(object sender, EventArgs e)
        {
            int i = 0;
            while (i < sayilar.Length)
            {
                lst_elemanlar.Items.Add(sayilar[i]);  //sayıların elemanlarını yazma
                i++;    //yok ise sonsuza gider
            }
        }

        private void btn_doWhile_Click(object sender, EventArgs e)
        {
            int i = 0;
            do
            {
                lst_elemanlar.Items.Add(programlar[i]);
                i++;

                if (i==programlar.Count)    //5 e kadar yazdırır
                {
                    break;
                }
                lst_elemanlar.Items.Add("-----------");

            } while (true);
        }

        private void btn_test_Click(object sender, EventArgs e)
        {
            int[] sayilar = new int[3] { 2, 3, 5 }; //[3] = indis değil eleman sayısıdır
        }
    }
}
