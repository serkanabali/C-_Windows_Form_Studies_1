﻿
namespace Hafta5
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_elemanlar = new System.Windows.Forms.ListBox();
            this.btn_for = new System.Windows.Forms.Button();
            this.btn_foreach = new System.Windows.Forms.Button();
            this.btn_while = new System.Windows.Forms.Button();
            this.btn_doWhile = new System.Windows.Forms.Button();
            this.btn_test = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lst_elemanlar
            // 
            this.lst_elemanlar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lst_elemanlar.FormattingEnabled = true;
            this.lst_elemanlar.ItemHeight = 20;
            this.lst_elemanlar.Location = new System.Drawing.Point(181, 12);
            this.lst_elemanlar.Name = "lst_elemanlar";
            this.lst_elemanlar.Size = new System.Drawing.Size(344, 184);
            this.lst_elemanlar.TabIndex = 0;
            // 
            // btn_for
            // 
            this.btn_for.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_for.Location = new System.Drawing.Point(12, 12);
            this.btn_for.Name = "btn_for";
            this.btn_for.Size = new System.Drawing.Size(98, 39);
            this.btn_for.TabIndex = 1;
            this.btn_for.Text = "For";
            this.btn_for.UseVisualStyleBackColor = true;
            this.btn_for.Click += new System.EventHandler(this.btn_for_Click);
            // 
            // btn_foreach
            // 
            this.btn_foreach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_foreach.Location = new System.Drawing.Point(12, 56);
            this.btn_foreach.Name = "btn_foreach";
            this.btn_foreach.Size = new System.Drawing.Size(98, 39);
            this.btn_foreach.TabIndex = 2;
            this.btn_foreach.Text = "ForEach";
            this.btn_foreach.UseVisualStyleBackColor = true;
            this.btn_foreach.Click += new System.EventHandler(this.btn_foreach_Click);
            // 
            // btn_while
            // 
            this.btn_while.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_while.Location = new System.Drawing.Point(12, 100);
            this.btn_while.Name = "btn_while";
            this.btn_while.Size = new System.Drawing.Size(98, 39);
            this.btn_while.TabIndex = 3;
            this.btn_while.Text = "While";
            this.btn_while.UseVisualStyleBackColor = true;
            this.btn_while.Click += new System.EventHandler(this.btn_while_Click);
            // 
            // btn_doWhile
            // 
            this.btn_doWhile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_doWhile.Location = new System.Drawing.Point(12, 144);
            this.btn_doWhile.Name = "btn_doWhile";
            this.btn_doWhile.Size = new System.Drawing.Size(98, 39);
            this.btn_doWhile.TabIndex = 4;
            this.btn_doWhile.Text = "DoWhile";
            this.btn_doWhile.UseVisualStyleBackColor = true;
            this.btn_doWhile.Click += new System.EventHandler(this.btn_doWhile_Click);
            // 
            // btn_test
            // 
            this.btn_test.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_test.Location = new System.Drawing.Point(12, 250);
            this.btn_test.Name = "btn_test";
            this.btn_test.Size = new System.Drawing.Size(98, 39);
            this.btn_test.TabIndex = 5;
            this.btn_test.Text = "Test";
            this.btn_test.UseVisualStyleBackColor = true;
            this.btn_test.Click += new System.EventHandler(this.btn_test_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 301);
            this.Controls.Add(this.btn_test);
            this.Controls.Add(this.btn_doWhile);
            this.Controls.Add(this.btn_while);
            this.Controls.Add(this.btn_foreach);
            this.Controls.Add(this.btn_for);
            this.Controls.Add(this.lst_elemanlar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lst_elemanlar;
        private System.Windows.Forms.Button btn_for;
        private System.Windows.Forms.Button btn_foreach;
        private System.Windows.Forms.Button btn_while;
        private System.Windows.Forms.Button btn_doWhile;
        private System.Windows.Forms.Button btn_test;
    }
}

